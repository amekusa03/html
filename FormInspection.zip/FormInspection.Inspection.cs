using IaiCorporation.AllPlatform.Misao.PhysicalTargetVirtualizationLayer2;
using IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.HistoryInspect;
using IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.OperateIFReg;
using IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.SpectroScope;
using PCBInspection_BarTypePhotoelectricSensor.Properties;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using static IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.CommonGui;
using static IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.ProcessingInternalPcbInspect;

namespace IaiCorporation.PCBInspection_BarTypePhotoelectricSensor
{
    public partial class FormInspection
    {
        // =====================================================================
        //  各検査ステップの実行メソッド群
        //  PostProcessingOfPage の switch から呼び出される。
        //  共通ヘルパー（ReadRegistersAsync / SendCommand2Async /
        //  ClearAllOutputPorts / FailInspectionAsync）は
        //  FormInspection.cs 末尾に定義してある。
        // =====================================================================

        /// <summary>検査機初期化処理</summary>
        private async Task InspectionDeviceInitialization()
        {
            try
            {
                // テストコール (200H) で RSEL 応答確認
                if (!OperateIFRegController.TestCall())
                {
                    AddLog(TypeLog.Bad, CaptionRSEL + MessageFailureResponse);
                    await EndInspection();
                    await CompleteWork(StatusProcess.NG);
                    return;
                }

                // システムステータス照会 (215H)
                StatusSystems statusSystem = OperateIFRegController.GetStatusSystem();
                if (statusSystem.NoErrorUserSystemParamountcy != 0)
                {
                    AddLog(TypeLog.Bad, CaptionRSEL + MessageFailureStatus);
                    await EndInspection();
                    if (currentDefinitionTable.PageId == (int)TypePage.InspectionDeviceInitialization)
                        await CompleteWork(StatusProcess.NG);
                    return;
                }

                // IO 全出力オフ (OutPort0=316 〜 OutPort15=331)
                ClearAllOutputPorts();

                StatusAxis[] statusAxis = OperateIFRegController.GetStatusAxis(TargetNoGroupAxis);
                Array.Resize(ref statusAxis, NumberAxisEffect);

                // サーボ ON (232H)
                if (statusAxis.Any(a => a.StatusServo == OFF))
                    OperateIFRegController.ChangeStateServo(true);

                // 原点復帰 (233H)
                if (statusAxis.Any(a => a.StatusHome == (int)StatusHome.Uncompleted))
                {
                    byte patternAxisEffect = (byte)OperateIFRegController.GetPatternAxisEffect(TargetNoGroupAxis);
                    OperateIFRegController.Home(TargetNoGroupAxis, patternAxisEffect);

                    bool isHomeCompleted = false;
                    await Task.Run(async () =>
                    {
                        while (true)
                        {
                            if (StopInspectionAuto) return;
                            statusAxis = OperateIFRegController.GetStatusAxis(TargetNoGroupAxis);
                            Array.Resize(ref statusAxis, NumberAxisEffect);
                            if (statusAxis.All(a => a.StatusHome == (int)StatusHome.Completed))
                            {
                                isHomeCompleted = true;
                                return;
                            }
                            await Task.Delay(3000);
                        }
                    });

                    if (StopInspectionAuto)
                    {
                        AddLog(TypeLog.Bad, currentDefinitionTable.PageName + CaptionStop);
                        await EndInspection();
                        return;
                    }

                    if (!isHomeCompleted)
                    {
                        AddLog(TypeLog.Bad, CaptionActuator + MessageFailureIsHome);
                        await EndInspection();
                        if (currentDefinitionTable.PageId == (int)TypePage.InspectionDeviceInitialization)
                            await CompleteWork(StatusProcess.NG);
                        return;
                    }
                }

                // 48V 電源 ON (OutPort6=322)
                OperateIFRegController.SetPortOne(OutPort6, ON);
                await Task.Delay(20);

                // 検査基板選択 → 対応ポート ON
                if (BoardInspectionPort.TryGetValue(historyInspect.InformationBasic.Substrate, out short port))
                    OperateIFRegController.SetPortOne(port, ON);

                if (currentDefinitionTable.PageId == (int)TypePage.InspectionDeviceInitialization)
                    await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>各種電圧確認</summary>
        private async Task VariousVoltageCheck()
        {
            try
            {
                // RSEL アナログ入力 CH1〜4 の AD 値確認
                List<ushort> listValuesAD = new List<ushort>();
                for (int i = 0; i < ListInPortCHAdStart.Count; i++)
                {
                    Dictionary<uint, uint> portData = OperateIFRegController.GetPort((short)ListInPortCHAdStart[i], SizeInPortCH_AD);
                    ushort port16 = (ushort)(portData[(uint)ListInPortCHAdStart[i]] & 0xFFFF);
                    listValuesAD.Add(port16);
                }

                for (int i = 0; i < listValuesAD.Count; i++)
                {
                    if (listValuesAD[i] < ListInPortCHAdLow[i] || listValuesAD[i] > ListInPortCHAdHeigh[i])
                    {
                        await FailInspectionAsync(ListCaptionCHErr[i]);
                        return;
                    }
                    AddLog(TypeLog.Good, currentDefinitionTable.PageName + ListCaptionCH[i]);
                }

                // CUStation Modbus アドレス 0x312: VSNS 電圧上位 4 bit 確認
                var readValue = await ReadRegistersAsync(VoltageVsnsRegisterAddress, 1);
                if (readValue == null) return;

                ushort readVoltageVSNS = (ushort)((readValue[0] >> 12) & 0xF);
                if (readVoltageVSNS < LowBatAD_Varios_CH4VSNS || readVoltageVSNS > HighBatAD_Varios_CH4VSNS)
                {
                    await FailInspectionAsync(ListCaptionCHErr[3]);
                    return;
                }

                await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>VP3R3 電圧確認</summary>
        private async Task VP3R3VoltageCheck()
        {
            try
            {
                Dictionary<uint, uint> portData = OperateIFRegController.GetPort((short)ListInPortCHAdStart[0], SizeInPortVP3R3_AD);
                ushort port16 = (ushort)(portData[(uint)ListInPortCHAdStart[0]] & 0xFFFF);

                if (port16 < LowBatAD_Varios_VP3R3 || port16 > HighBatAD_Varios_VP3R3)
                {
                    // [バグ修正] 元コードは return が抜けていたため NG 後も OK 処理に落ちていた
                    await FailInspectionAsync(MessageFailureVoltage);
                    return;
                }

                await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>スイッチ動作確認</summary>
        private async Task SwitchOperationCheck()
        {
            try
            {
                // コントローラ種別コード確認 (Modbus 0x0300)
                var readValue = await ReadRegistersAsync(ControllerTypeRegisterAddress, ReadRegisterCount);
                if (readValue == null) return;

                uint controllerType = ((uint)readValue[0] << 16) | readValue[1];
                if (DefControllerType != controllerType)
                {
                    await FailInspectionAsync(MessageFailureType);
                    return;
                }

                // アクチュエータ ポジション1移動 (A スイッチ ON)
                if (await RCDAxisiMove(Position1, 1) != InspectionResult.OK) return;
                await Task.Delay(4000);

                // ポジション1に戻す (A スイッチ OFF)
                if (await RCDAxisiMove(Position1, 1) != InspectionResult.OK) return;

                // CUStation 再接続 SA[2]
                if (!await CUStationDisConnection()) return;
                CuConnectionSA = 2;
                if (!await CUStationConnection()) return;

                // アドレス変更後 コントローラ種別コード再確認
                var readValue2 = await ReadRegistersAsync(ControllerTypeRegisterAddress, ReadRegisterCount);
                if (readValue2 == null) return;

                uint controllerType2 = ((uint)readValue2[0] << 16) | readValue2[1];
                if (DefControllerType != controllerType2)
                {
                    await FailInspectionAsync(MessageFailureAddressChange);
                    return;
                }

                // ソフトウェアリセット (0x0024)
                OperateCUStationController.ControlCommand2(CuDeviceNo, CuCommandSA, Command2ResetSoftware, 0x00000000, 0, 0, 0);
                await Task.Delay(1000);

                if (!await CUStationDisConnection()) return;
                CuConnectionSA = 2;
                if (!await CUStationConnection()) return;

                await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ReadingRegistersTcs = null;
            }
        }

        /// <summary>RCD アクチュエーター移動</summary>
        private async Task<InspectionResult> RCDAxisiMove(int position, byte axis)
        {
            try
            {
                await PreparationMoveAxis();

                if (StopInspectionAuto)
                {
                    OperateIFRegController.StopMove();
                    AddLog(TypeLog.Bad, currentDefinitionTable.PageName + CaptionStop);
                    return InspectionResult.STOP;
                }

                Func<Task> waitMoveCompleted = async () =>
                {
                    while (true)
                    {
                        if (StopInspectionAuto)
                        {
                            AddLog(TypeLog.Bad, currentDefinitionTable.PageName + CaptionStop);
                            return;
                        }
                        StatusAxis[] statusAxis = OperateIFRegController.GetStatusAxis(TargetNoGroupAxis);
                        Array.Resize(ref statusAxis, NumberAxisEffect);
                        if (statusAxis.All(a => a.CompleteCommandMove == ON)) return;
                        await Task.Delay(IntervalWaitTimeMove);
                    }
                };

                OperateConditionsMoveDirect move = new OperateConditionsMoveDirect
                {
                    Velocity     = VelocityTestRoundTrip,
                    Acceleration = AccelerationTestRoundTrip,
                    Deceleration = DecelerationTestRoundTrip,
                    TypeCoord    = TypeCoordTestRoundTrip,
                    TypeMove     = TyoeMoveTestRoundTrip,
                    Position     = Enumerable.Repeat(position, MaxQuantityAxis).ToArray(),
                };

                OperateIFRegController.MoveDirect(TargetNoGroupAxis, move, axis);
                await waitMoveCompleted();

                if (StopInspectionAuto)
                {
                    OperateIFRegController.StopMove();
                    AddLog(TypeLog.Bad, currentDefinitionTable.PageName + CaptionStop);
                    return InspectionResult.STOP;
                }

                StatusSystems statusSystem = OperateIFRegController.GetStatusSystem();
                return statusSystem.NoErrorUserSystemParamountcy != 0 ? InspectionResult.NG : InspectionResult.OK;
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                if (OperateIFRegController.IsStateConnected) OperateIFRegController.StopMove();
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return InspectionResult.ERROR;
            }
        }

        /// <summary>ネットワーク・センサー接続確認</summary>
        private async Task NetworkSensorConnectionCheck()
        {
            ushort readStartAddress = (ushort)(CuCommandSA * 8);
            ushort readByteCount = 8;
            try
            {
                for (int i = 0; i < 3; i++)
                {
                    clsBayType clswk = new clsBayType();
                    byte[] readDataArray = OperateCUStationController.CURead(CuDeviceNo, readStartAddress, readByteCount);
                    if (readDataArray != null)
                    {
                        clswk.RDY   = (int)(readDataArray[1] & 0x80 >> 7);
                        clswk.SENS  = (int)(readDataArray[0] & 0x01);
                        clswk.WDR91 = (int)(readDataArray[5] & 0x01);
                        clswk.WDS   = (int)(readDataArray[3] & 0x01);
                    }
                    await Task.Delay(200);

                    if (clswk.RDY != 1 || clswk.SENS != 1 || clswk.WDS != 0)
                    {
                        await FailInspectionAsync(MessageFailureDistanceMeasurement);
                        return;
                    }
                    if (clswk.WDR91 == 0)
                    {
                        await FailInspectionAsync(MessageFailureWorkDetect);
                        return;
                    }
                }

                await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>感度調整回路動作確認</summary>
        private async Task SensitivityAdjustmentCircuitOperationCheck()
        {
            ushort registerCount = 9;
            try
            {
                // 感度設定初期値確認 (0x0040)
                var readValue = await ReadRegistersAsync(SensitivitySettingsAddress, registerCount);
                if (readValue == null) return;

                uint readSensitivity = ((uint)readValue[0] << 16) | readValue[1];
                if (DefSensitivitySettings != readSensitivity)
                {
                    await FailInspectionAsync(MessageFailureDgpInitial);
                    return;
                }

                await Task.Delay(4000);

                // 全チャンネルを 0x007F に書込み
                List<ushort> writeData = Enumerable.Repeat(WriteSensitivitySettings, (int)registerCount).ToList();
                if (!OperateCUStationController.PresetMultipleRegisters(CuDeviceNo, CuCommandSA, SensitivitySettingsAddress, writeData))
                {
                    AddLog(TypeLog.Bad, currentDefinitionTable.PageName + MessageFailureWriteRegister);
                    MessageBox.Show(currentDefinitionTable.PageName + MessageFailureWriteRegister,
                                    MessageBoxCaption_Warning, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                await Task.Delay(4000);

                // 書込み値確認 (0x007F)
                var readValue2 = await ReadRegistersAsync(SensitivitySettingsAddress, registerCount);
                if (readValue2 == null) return;

                uint readSensitivity2 = ((uint)readValue2[0] << 16) | readValue2[1];
                if (WriteSensitivitySettings != readSensitivity2)
                {
                    await FailInspectionAsync(MessageFailureDgpWrite);
                    return;
                }

                // 感度設定を初期値 (0x0040) に戻す
                List<ushort> restoreData = Enumerable.Repeat(DefSensitivitySettings, (int)registerCount).ToList();
                if (!OperateCUStationController.PresetMultipleRegisters(CuDeviceNo, CuCommandSA, SensitivitySettingsAddress, restoreData))
                {
                    AddLog(TypeLog.Bad, currentDefinitionTable.PageName + MessageFailureWriteRegister);
                    MessageBox.Show(currentDefinitionTable.PageName + MessageFailureWriteRegister,
                                    MessageBoxCaption_Warning, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>センサー回路動作確認</summary>
        private async Task SensorCircuitOperationCheck()
        {
            try
            {
                // オブジェクト検知確認 (Modbus 0x1502) × 3 回
                // [バグ修正] 元コードはアウター/インナーで同じ変数 i を共用しており
                //            readRegisterCount=1 時に無限ループになっていた
                for (int trial = 0; trial < 3; trial++)
                {
                    var readValue = await ReadRegistersAsync(ObjectDetectionAddress, 1);
                    if (readValue == null) return;

                    if (DefObjectDetection != readValue[0])
                    {
                        await FailInspectionAsync(MessageFailureObjectDetection);
                        return;
                    }
                }

                // 余裕度確認 (Modbus 0x151A〜0x1522) × 3 回
                for (int trial = 0; trial < 3; trial++)
                {
                    var readValue = await ReadRegistersAsync(ReferenceValueAddress, 9);
                    if (readValue == null) return;

                    if (readValue.Any(v => DefReferenceValue > v))
                    {
                        await FailInspectionAsync(MessageFailureMalleability);
                        return;
                    }
                }

                // 基板温度確認 (Modbus 0x0310) × 3 回
                for (int trial = 0; trial < 3; trial++)
                {
                    var readValue = await ReadRegistersAsync(TemperatureAddress, 1);
                    if (readValue == null) return;

                    if (DefTemperature < (int)readValue[0])
                    {
                        await FailInspectionAsync(MessageFailureSubstrateTemperature);
                        return;
                    }
                }

                await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>LED 表示確認</summary>
        private async Task LEDDisplayCheck()
        {
            try
            {
                SpectroScopeController = new SpectroScopeController();
                if (!SpectroScopeController.Initialize()) return;

                // 検査モード設定 (0xFFFF, op1=1)
                if (!await SendCommand2Async(Command2InspectionMode, Command2OperandValue1, 0, MessageFailureInspectionModeError)) return;

                // ポジション4移動 (LED1 検出位置)
                if (await RCDAxisiMove(Position4, 2) != InspectionResult.OK) return;

                // LED1 緑点灯 (op2=1) → 波長575nm 強度確認
                if (!await SendCommand2Async(Command2LEDOnOff, Command2OperandValue1, Command2OperandValue1, MessageFailureLED1G)) return;
                if (!SpectroScopeController.GetLEDSpectroScope(575, ref LedPower)) return;
                if (LedPower < Spectrometer575)
                {
                    await FailInspectionAsync(MessageFailureLED1G);
                    return;
                }

                // LED1 橙点灯 (op2=2) → 波長611nm 強度確認
                if (!await SendCommand2Async(Command2LEDOnOff, Command2OperandValue1, (uint)(Command2OperandValue1 << 1), MessageFailureLED1O)) return;
                if (!SpectroScopeController.GetLEDSpectroScope(611, ref LedPower)) return;
                if (LedPower < Spectrometer611)
                {
                    await FailInspectionAsync(MessageFailureLED1O);
                    return;
                }

                // ポジション3移動 (LED2 検出位置)
                if (await RCDAxisiMove(Position3, 2) != InspectionResult.OK) return;

                // LED2 緑点灯 (op2=4) → 波長575nm 強度確認 (閾値は Spectrometer611)
                if (!await SendCommand2Async(Command2LEDOnOff, Command2OperandValue1, (uint)(Command2OperandValue1 << 2), MessageFailureLED2G)) return;
                if (!SpectroScopeController.GetLEDSpectroScope(575, ref LedPower)) return;
                if (LedPower < Spectrometer611)
                {
                    await FailInspectionAsync(MessageFailureLED2G);
                    return;
                }

                // 分光器切断
                if (!SpectroScopeController.DisConnect()) return;

                // LED 消灯 (op1=0, op2=0)
                if (!await SendCommand2Async(Command2LEDOnOff, Command2OperandValue0, Command2OperandValue0, MessageFailureLEDNormal)) return;

                // 通常モード設定 (0xFFFF, op1=0)
                if (!await SendCommand2Async(Command2InspectionMode, Command2OperandValue0, 0, MessageFailureNormalModeError)) return;

                await CompleteWork(StatusProcess.OK);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Warning, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>出荷パラメーター書込み処理</summary>
        private async Task WriteParameter()
        {
            try
            {
                string selectedSubstrate = historyInspect.InformationBasic.Substrate;
                string strLotNumber = historyInspect.TargetInspection.LotNo;
                ushort lotNumber0 = Convert.ToUInt16(strLotNumber.Substring(0, 4), 16);
                ushort lotNumber1 = Convert.ToUInt16(strLotNumber.Substring(4, 4), 16);

                // 製造情報カテゴリ書込み許可
                if (!OperateCUStationController.ControlCommand2(CuDeviceNo, CuCommandSA, Command2WritePermission, Command2OperandValue1, 0, 0, 0)) return;
                await Task.Delay(500);

                // 検査日 → 16進数エンコード
                DateTime date = DateTime.ParseExact(historyInspect.InformationBasic.DataInspect,
                                                    "yyyy/MM/dd (ddd) HH:mm:ss",
                                                    CultureInfo.GetCultureInfo("ja-JP"));
                ushort yearHex     = (ushort)date.Year;
                ushort monthDayHex = (ushort)((date.Month << 8) | date.Day);

                // 基板種別ごとに書き込み先アドレスを決定して書込み
                ushort[] writeAddresses = GetWriteParameterAddresses(selectedSubstrate);
                foreach (ushort addr in writeAddresses)
                {
                    List<ushort> writeData = new List<ushort> { yearHex, monthDayHex, lotNumber0, lotNumber1 };
                    if (!OperateCUStationController.PresetMultipleRegisters(CuDeviceNo, CuCommandSA, addr, writeData)) return;
                    await Task.Delay(1000);
                }

                // 製造情報カテゴリ書込み禁止
                if (!OperateCUStationController.ControlCommand2(CuDeviceNo, CuCommandSA, Command2WritePermission, Command2OperandValue0, 0, 0, 0)) return;
                await Task.Delay(500);

                // 不揮発性記憶領域パラメーター書込み
                int startBoard = selectedSubstrate == "IABM13801-000" ? 0 : 2;
                for (int i = startBoard; i <= startBoard + 1; i++)
                {
                    if (!OperateCUStationController.ControlCommand2(CuDeviceNo, CuCommandSA, Command2WriteParameter, Command2OperandValueA, (uint)i, 0, 0)) return;
                    await Task.Delay(500);
                }

                // CSTS.PARW=1 (アドレス 0xE01A bit0) になるまで最大 20 秒ポーリング
                int timeoutMs = 20000;
                int pollMs    = 500;
                var sw = Stopwatch.StartNew();
                while (sw.ElapsedMilliseconds < timeoutMs)
                {
                    var readValue = await ReadRegistersAsync(TransportStatusRegisterAddress, ReadRegisterCount);
                    if (readValue == null) return;

                    if ((readValue[0] & 0x0001) == 1)
                    {
                        AddLog(TypeLog.Good, CaptionWriteParameter + CaptionCompleted);
                        await CompleteWork(StatusProcess.Complete);
                        return;
                    }
                    await Task.Delay(pollMs);
                }

                // タイムアウト → 不合格
                AddLog(TypeLog.Bad, CaptionActuator + MessageFailureIsHome);
                await EndInspection();
                await CompleteWork(StatusProcess.NG);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>基板種別から製造情報書込みアドレス一覧を返す</summary>
        private static ushort[] GetWriteParameterAddresses(string substrate)
        {
            if (substrate == "IABM13801-000")
                return new[] { ManufacturingInformationMasterRegisterAddress, ManufacturingInformationSlave1RegisterAddress };
            if (substrate == "IABS13801-000" || substrate == "IABS13801-001")
                return new[] { ManufacturingInformationSlave2RegisterAddress, ManufacturingInformationSlave3RegisterAddress };
            return Array.Empty<ushort>();
        }

        /// <summary>検査完了処理（保存・印刷・画面クローズ）</summary>
        private void CompletedInspection()
        {
            try
            {
                if (DialogResult.Yes != MessageBox.Show(MessageInspectionComplete,
                                                        CommonGui.MessageBoxCaption_Question,
                                                        MessageBoxButtons.YesNo,
                                                        MessageBoxIcon.Question))
                    return;

                // 検査結果を HistoryInspect に格納
                historyInspect.SettingsTool.RequirementVerFirmwareMain = Settings.Default.RequirementVerFirmwareMain;

                void SetResult(TypePage page, Action<bool> setter)
                {
                    if (CurrentTargetPageIds.Contains((int)page))
                        setter(listDefinition.Any(x => x.PageId == (int)page));
                }

                SetResult(TypePage.InputInspectionInformation,                  v => historyInspect.Result.ResultInputInspectionInformation = v);
                SetResult(TypePage.InspectionDeviceInitialization,              v => historyInspect.Result.ResultInspectionDeviceInitialization = v);
                SetResult(TypePage.VariousVoltageCheck,                         v => historyInspect.Result.ResultVariousVoltageCheck = v);
                SetResult(TypePage.VP3R3VoltageCheck,                           v => historyInspect.Result.ResultVP3R3VoltageCheck = v);
                SetResult(TypePage.SwitchOperationCheck,                        v => historyInspect.Result.ResultSwitchOperationCheck = v);
                SetResult(TypePage.NetworkSensorConnectionCheck,                v => historyInspect.Result.ResultNetworkSensorConnectionCheck = v);
                SetResult(TypePage.SensitivityAdjustmentCircuitOperationCheck,  v => historyInspect.Result.ResultSensitivityAdjustmentCircuitOperationCheck = v);
                SetResult(TypePage.SensorCircuitOperationCheck,                 v => historyInspect.Result.ResultSensorCircuitOperationCheck = v);

                historyInspect.Result.ResultLEDDisplayCheck          = listDefinition.Any(x => x.PageId == (int)TypePage.LEDDisplayCheck);
                historyInspect.Result.ResultSettingShippingParameter = listDefinition.Any(x => x.PageId == (int)TypePage.WriteParameter);
                historyInspect.Other.Comment = textboxComment.Text;

                SaveFileHistoryInspect(historyInspect, true);
                if (!AddIndexFiles(historyInspect)) throw new Exception();

                try
                {
                    PrintReportInspection(new HistoryInspectPCB(historyInspect));
                }
                catch (Exception ex)
                {
                    Debugger.Log(0, ex.GetType().Name, ex.ToString());
                    AddLog(TypeLog.Bad, MessageHandlingExceptionPrintOutReportShort);
                    MessageBox.Show(MessageHandlingExceptionPrintOutReportLong,
                                    MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                AddLog(TypeLog.Good, $"{currentDefinitionTable.PageName}{GetEnumDescription(StatusProcess.Complete)}");
                isAllowFormClose = true;
                this.Close();
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());
                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
