﻿using IaiCorporation.AllPlatform.Misao.PhysicalTargetAccessLayer2;
using IaiCorporation.AllPlatform.Misao.PhysicalTargetVirtualizationLayer2;
using IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.CUStation;
using IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.HistoryInspect;
using IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.OperateIFReg;
using IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.SpectroScope;
using PCBInspection_BarTypePhotoelectricSensor.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.CommonGui;
using static IaiCorporation.PCBInspection_BarTypePhotoelectricSensor.ProcessingInternalPcbInspect;

namespace IaiCorporation.PCBInspection_BarTypePhotoelectricSensor
{

    /// <summary>
    /// PCB検査画面
    /// </summary>
    /// <remarks>-</remarks>
    /// <revisionHistory>
    ///   <revision date="2023/12/07" version="Ver.1.0.0.0" author="M.Numano">
    ///     新規作成
    ///   </revision>
    /// </revisionHistory>
    public partial class FormInspection : Form
    {
        /// <summary>
        /// PCB検査画面定義テーブル
        /// </summary>
        protected class DefinitionTable
        {
            /// <summary>ページID</summary>
            public int PageId { get; set; }

            /// <summary>試験区分</summary>
            public int TypeInspect { get; set; }

            /// <summary>工程区分</summary>
            public int TypeWork { get; set; }

            /// <summary>検査情報の表示有無</summary>
            public bool IsInfoInspection { get; set; }

            /// <summary>検査基板選択&回路切替の表示有無</summary>
            public bool IsBoardInspection { get; set; }

            /// <summary>検査履歴コメント表示有無</summary>
            public bool IsVisibleHistoryComment { get; set; }

            /// <summary>接触抵抗試験測定値表示有無</summary>
            public bool IsVisibleValueMeasured { get; set; }

            /// <summary>パラメータ設定UserControl表示有無</summary>
            public bool IsVisibleSetParameter { get; set; }

            /// <summary>フッタータイプ</summary>
            public int TypeFooter { get; set; }

            /// <summary>フッターボタン表示名(フッタータイプが0のみ設定する)</summary>
            public string DisplayFooterName { get; set; }

            /// <summary>サブボタン表示有無</summary>
            public bool IsVisibleButtonSub { get; set; }

            /// <summary>サブボタン表示名</summary>
            public string DisplayButtonSub { get; set; }

            /// <summary>作業指示表示</summary>
            public bool IsVisibleWorkInstruction { get; set; }

            /// <summary>ページ名</summary>
            public string PageName { get; set; }

            /// <summary>検査項目説明</summary>
            public string Description { get; set; }

            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="PageId">ページID</param>
            /// <param name="TypeInspect">試験区分</param>
            /// <param name="TypeWork">工程区分</param>
            /// <param name="IsVisibleIllustration">説明図の表示有無</param>
            /// <param name="IsInfoInspection">検査情報の表示有無</param>
            /// <param name="IsBoardInspection">検査基板選択&回路切替の表示有無</param>
            /// <param name="IsVisibleHistoryComment">検査履歴コメント表示有無</param>
            ///// <param name="IsVisibleValueMeasured">接触抵抗試験測定値表示有無</param>
            /// <param name="TypeFooter">フッタータイプ</param>
            /// <param name="DisplayFooterName">フッターボタン表示名(フッタータイプが0のみ設定する)</param>
            /// <param name="IsVisibleButtonSub">サブボタン表示有無</param>
            /// <param name="DisplayButtonSub">サブボタン表示名</param>
            /// <param name="IsVisibleSetParameter">パラメータ設定UserControl表示有無</param>
            /// <param name="IsVisibleWorkInstruction">作業指示表示</param>
            public DefinitionTable(
                int PageId, int TypeInspect, 
                int TypeWork, 
                bool IsInfoInspection, 
                bool IsBoardInspection,
                bool IsVisibleHistoryComment,
                int TypeFooter, 
                string DisplayFooterName, 
                bool IsVisibleButtonSub, 
                string DisplayButtonSub, 
                bool IsVisibleSetParameter, 
                bool IsVisibleWorkInstruction
                )
            {
                this.PageId = PageId;
                this.TypeInspect = TypeInspect;
                this.TypeWork = TypeWork;
                this.IsInfoInspection = IsInfoInspection;
                this.IsBoardInspection = IsBoardInspection;
                this.IsVisibleHistoryComment = IsVisibleHistoryComment;
                this.TypeFooter = TypeFooter;
                this.DisplayFooterName = DisplayFooterName;
                this.IsVisibleButtonSub = IsVisibleButtonSub;
                this.DisplayButtonSub = DisplayButtonSub;
                this.IsVisibleSetParameter = IsVisibleSetParameter;
                this.IsVisibleWorkInstruction = IsVisibleWorkInstruction;
            }
        }

        /// <summary>
        /// バー型光電センサー取得値格納クラス
        /// </summary>
        /// <remarks>-</remarks>
        /// <revisionHistory>
        ///   <revision date="2025/06/30" version="Ver.1.0.0.0" author="SCC">
        ///     新規作成
        ///   </revision>
        /// </revisionHistory>
        protected class clsBayType
        {
            /// <summary>RDY</summary>
            public int RDY { get; set; }
            /// <summary>SENS</summary>
            public int SENS { get; set; }
            /// <summary>WDS</summary>
            public int WDS { get; set; }
            /// <summary>WDR91</summary>
            public int WDR91 { get; set; }
        }

        ///PCB検査画面定義テーブル
        protected List<DefinitionTable> listDefinition = null;

        /// <summary>現在実行中の検査項目</summary>
        protected DefinitionTable currentDefinitionTable;

        /// <summary>検査履歴</summary>
        protected HistoryInspectPCB historyInspect = new HistoryInspectPCB();

        /// <summary>画面ロード完了フラグ</summary>
        protected bool loadComplate = false;

        /// <summary>画面クローズ成立フラグ</summary>
        protected bool CloseHold = false;

        /// <summary>画面クローズ許可フラグ</summary>
        private bool isAllowFormClose = true;

        /// <summary>有効軸数</summary>
        /// <remarks>
        ///     製造指示書のコントローラー型式上に存在するドライバ数．
        ///     物理軸Noの若いドライバから順に論理軸No1,2,3…と割り当てられる．
        ///     そのため，型式上に存在するドライバ数＝有効軸数．
        /// </remarks>
        private int NumberAxisEffect = 2;

        /// <summary>評価対象の軸グループNo.</summary>
        private const int TargetNoGroupAxis = 1;

        //>RSEL(2)出力ポート一覧
        public List<int> OutPortAllRselSecond = new List<int>();

        /// <summary>>AUTO/MANU切り替え指示ラベル点滅処理のキャンセルトークン</summary>
        CancellationTokenSource CancellationTokenSourceBlinkingInstruction = new CancellationTokenSource();

        /// <summary>中止フラグ</summary>
        private bool stopInspectionAuto = false;
        static Object lockObj = new Object();

        /// <summary>コンテキストメニュー表示可能フラグ</summary>
        private bool IsEnableContextMenu = true;

        public Color colorCheckManual = Color.FromArgb(245, 245, 255);                  //手作業による確認項目
        public Color colorCheckPartiallyAutomated = Color.FromArgb(225, 225, 255);      //一部自動化された確認項目
        public Color colorCheckAllAutomated = Color.FromArgb(210, 210, 255);            //全て自動化された確認項目
        public Color colorWorkManual = Color.FromArgb(230, 255, 230);                   //手作業による作業項目
        public Color colorWorkAutomated = Color.FromArgb(185, 255, 185);                //全て自動化された作業項目

        /// <summary>ハンディQRコードリーダーで読み取った製番 ※絶縁耐圧試験のみ用</summary>
        private string ProdactNoOnlyTestElectricStrength = string.Empty;

        ///// <summary>出荷パラメーター設定のスクリーンショットの一時保存</summary>
        //private Bitmap BitmapScreenshotsWithShippingPparameterSettings = null;

#if CHECK_OPERATION
        /// <summary>PCB検査画面ページ指定起動関連 ページ絞り込みのID</summary>
        public int IdSelectPage { get; set; }
#endif

        /// <summary>
        /// 自動検査中止用プロパティ
        /// </summary>
        public bool StopInspectionAuto
        {
            get
            {
                lock (lockObj)
                {
                    return stopInspectionAuto;
                }
            }

            set
            {
                lock (lockObj)
                {
                    stopInspectionAuto = value;
                }
            }
        }

        /// <summary> CUStationデバイス番号 </summary>
        private byte CuDeviceNo = 0;

        /// <summary> CUStation接続用SA </summary>
        private int CuConnectionSA = 2;

        /// <summary> CUStationコマンド用SA </summary>
        private int CuCommandSA;

        /// <summary>メモリ読込アドレス</summary>
        private ushort CuMemoryAddress;

        /// <summary>メモリ読込バイト</summary>
        private ushort CuMemoryByte;

        /// <summary>分光器強度（波長575）</summary>
        private ushort Spectrometer575;

        /// <summary>分光器強度（波長611）</summary>
        private ushort Spectrometer611;

        /// <summary>現在選択されている基板グループに対応する検査ページのIDリスト</summary>
        private List<int> CurrentTargetPageIds = new List<int>();

        /// <summary>ReadingRegistersProgressEventのイベント監視用</summary>
        private TaskCompletionSource<ReadingRegistersProgressEventArgs> ReadingRegistersTcs;

        /// <summary>指令コマンド2の受信イベント監視用</summary>
        private TaskCompletionSource<ControlCommand2ReceivedEventArgs> Command2ReceiveTcs;

        /// <summary>レジスタ書き込み TransmissionRegistersProgressEventArgのイベント監視用</summary>
        private TaskCompletionSource<TransmissionRegistersProgressEventArgs> TransmissionRegistersTcs;

        /// <summary>分光器操作用クラス</summary>
        private SpectroScopeController SpectroScopeController;

        /// <summary>Capture mode</summary>
        enum E_CAPTUREMODE
        {
            /// <summary>Free run mode</summary>
            D_CAPTUREMODE_FREERUN = 0x00000000,
            /// <summary>/Trigger mode</summary>
            D_CAPTUREMODE_TRIGGER = 0x00000001,
        };

        /// <summary>LEDモード </summary>
        Int32 LedMode = 0;

        /// <summary>LED出力 </summary>
        Int32 LedPower = 0;


        #region const
        /// <summary>メッセージ</summary>
        protected const int SizeFontLabelDescription = 20;
        const int Empty = -1;

        protected const string CaptionRSEL = "RSEL";
        protected const string CaptionCUStation = "CUStation";
        protected const string CaptionActuator = "アクチュエーター";
        protected const string CaptionRetry = "リトライ";
        protected const string CaptionStop = "中止";
        protected const string CaptionPass = "合格";
        protected const string CaptionFail = "不合格";
        protected const string CaptionWriteParameter = "パラメーター書込み";
        protected const string CaptionCompleted = "完了";
        protected const string CaptionSave = "保存";
        protected const string CaptionUnitAccessories = "付属品ユニット";
        protected const string CaptionSymbolLoad = "Load";
        protected const string CaptionSymbolClose = "Close";
        protected const string CaptionStart = "開始";
        protected const string CaptionEnd = "終了";
        protected const string CaptionConnected = "通信確立";
        protected const string CaptionInProgress = "実行中";
        protected const string CaptionDo = "中";
        protected const string CaptionAlarmReset = "アラームリセット";
        protected const string CaptionVarios = "各種電圧";
        protected const string CaptionVP3R3 = "VP3R3電圧";
        protected const string CaptionCommand2Result = "指令コマンド受信結果";


        protected const string MessageReadFailureLog = "の読み込みに失敗";
        protected const string MessageReadFailure = "の読み込みに失敗しました。";

        protected const string MessageOccurrenceException = "例外発生";
        protected const string MessageHandlingException = "に失敗しました。\r\n検査ソフトの設定や、検査機の状態に異常が無いか確認してください。";
        protected const string MessageHandlingExceptionPrintOutReportShort = "検査成績書印刷失敗";
        protected const string MessageHandlingExceptionPrintOutReportLong = "検査成績書の印刷に失敗しました。\r\nプリンターとの通信を確認し、検査履歴画面から印刷してください。";

        protected const string MessageFailureResponse = "レスポンスエラー";
        protected const string MessageFailureStatus = "ステータスエラー";
        protected const string MessageFailureVoltage = "電圧エラー";
        protected const string MessageFailureIsHome = "原点復帰エラー";
        protected const string MessageFailureTimeout = "タイムアウト";
        protected const string MessageFailureType = "センサーアクセスエラー";
        protected const string MessageFailureAddressChange = "アドレス変更エラー";
        protected const string MessageFailureDistanceMeasurement = "デバイスステータス異常";
        protected const string MessageFailureWorkDetect = "ワーク検出異常";
        protected const string MessageFailureDgpInitial = "DGP初期値異常";
        protected const string MessageFailureDgpWrite = "DGP書込み異常";
        protected const string MessageFailureObjectDetection = "オブジェクト検知異常";
        protected const string MessageFailureMalleability = "余裕度異常";
        protected const string MessageFailureSubstrateTemperature = "基板温度異常";
        protected const string MessageFailureWriteRegister = "レジスタ書き込み失敗";

        protected const string MessageFailureSpectroScopeInitialize = "初期化エラー";
        protected const string MessageFailureSpectroScopeUnInitialize = "初期化解除エラー";
        protected const string MessageFailureSpectroScopeConnectDevice = "接続デバイス取得エラー";
        protected const string MessageFailureSpectroScopeOpenDevice = "接続デバイスオープンエラー";
        protected const string MessageFailureSpectroScopeCloseDevice = "接続デバイスクローズエラー";
        protected const string MessageFailureSpectroScopeModelInfomation = "モデル情報取得エラー";
        protected const string MessageFailureInspectionModeError = "検査モード設定エラー";
        protected const string MessageFailureNormalModeError = "通常モード設定エラー";

        protected const string MessageFailureLED1G = "ステータスLED点灯エラー（LED1緑）";
        protected const string MessageFailureLED1O = "ステータスLED点灯エラー（LED1橙）";
        protected const string MessageFailureLED2G = "ステータスLED点灯エラー（LED2緑）";
        protected const string MessageFailureLED2O = "ステータスLED点灯エラー（LED2橙）";
        protected const string MessageFailureLEDNormal = "ステータスLED通常設定エラー";

        protected const string MessageFailureConnection = "接続失敗";
        protected const string MessageFailureDisConnection = "切断失敗";
        protected const string MessageHandlingFailureConnection = "との接続に失敗しました。\r\n検査ソフトの設定や、検査機の状態に異常が無いか確認してください。";
        protected const string MessageHandlingFailureDisConnection = "との切断に失敗しました。\r\n検査ソフトの設定や、検査機の状態に異常が無いか確認してください。";

        protected const string MessageInspectionComplete = "PCB検査が完了しました。検査結果は合格です。検査成績書を出力し、PCB検査を終了します。";

        protected const string MessageFailedToUpdateLogFile = "logファイルの更新に失敗しました。";
        protected const string MessageFailedEnd = "正しく終了しませんでした。";

        protected const string MessageNotSettingInspectorShort = "検査情報入力未完";
        protected const string MessageNotSettingInspectorLong = "検査者名を設定してください。";

        protected const string MessageNotBoardselectShort = "検査基板選択未完";
        protected const string MessageNotBoardselectLong = "検査基板を選択してください。";

        protected const string MessageNoSubstrateLotNumberShort = "基板ロット番号入力未完";
        protected const string MessageNoSubstrateLotNumberLong = "基板ロット番号を８桁で設定してください。";

        protected virtual string CaptionThis => "PCB検査";
        protected virtual string MessageCompleteOK => "PCB検査が完了しました。PCB検査の結果は合格です。PCB検査を終了します。";
        protected virtual string MessageCompleteNG => "検査結果は不合格です。";

        /// <summary>各種電圧確認 キャプション一覧</summary>
        protected List<String> ListCaptionCH = new List<String>() { "VP5電源電圧", "VP3R3電源電圧", "VOUT30(MKY49)電圧", "VOUT12(MKY49)電圧" };
        protected List<String> ListCaptionCHErr = new List<String>() { "VP5電源電圧エラー", "VP3R3電源電圧エラー", "VOUT30(MKY49)電圧エラー", "VOUT12(MKY49)電圧エラー" };
        /// <summary>各種電圧確認 電圧AD値INポート一覧</summary>
        protected List<int> ListInPortCHAdStart = new List<int>() { InPortCH1_AD_Start, InPortCH2_AD_Start, InPortCH3_AD_Start, InPortCH4_AD_Start };
        /// <summary>各種電圧確認 電圧AD値範囲（下限）</summary>
        protected List<int> ListInPortCHAdLow = new List<int>() { LowBatAD_Varios_CH1, LowBatAD_Varios_CH2, LowBatAD_Varios_CH3, LowBatAD_Varios_CH4 };
        /// <summary>各種電圧確認 電圧AD値範囲（上限）</summary>
        protected List<int> ListInPortCHAdHeigh = new List<int>() { HighBatAD_Varios_CH1, HighBatAD_Varios_CH2, HighBatAD_Varios_CH3, HighBatAD_Varios_CH4 };

        /// <summary>分光器用定義　モジュール名</summary>
        protected const string ModelNameC15934 = "C15394";

        #endregion const


        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="IsSkipTestElectricStrength">絶縁耐圧試験スキップフラグ</param>
        /// <param name="IsOnlyTestElectricStrength">絶縁耐圧試験のみフラグ</param>
        /// <returns>-</returns>
        /// <remarks>-</remarks>
        /// <exception>-</exception>
        /// <revisionHistory>
        ///   <revision date="2023/8/29" version="Ver.1.0.0.0" author="Y.Hirose">
        ///     新規作成
        ///   </revision>
        /// </revisionHistory>
        public FormInspection(bool IsSkipTestElectricStrength, bool IsOnlyTestElectricStrength)
        {

            InitializeComponent();

        }

        /// <summary>
        /// ロードイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual async void FormInspection_Load(object sender, EventArgs e)
        {
            //ログクリア
            richtextboxLog.Text = string.Empty;

            AddLog(TypeLog.Neither, CaptionThis + CaptionStart);

            try
            {
                //PCB検査画面定義テーブル作成
                CreateDefinitionTable();

                //DefinitionFormInspection.csvを読み込み
                GetInspectItem(FileNameDefinitionFormInspection);
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                AddLog(TypeLog.Bad, FileNameDefinitionFormInspection + MessageReadFailureLog);

                MessageBox.Show(FileNameDefinitionFormInspection + MessageReadFailure,
                                MessageBoxCaption_Error,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                //画面を閉じる
                this.Close();
                return;
            }

            //panelListBaseにセットするPanelをリスト化
            List<Panel> addList = new List<Panel>
            {
                panelListStart,         //▼ START ▼
                panelListItem,          //検査項目一覧
                panelQRReadInstruction, //製造指示書のQRコードを読み取り検査対象を確定させてください
                panelListEnd,           //■ END ■
            };

            //panelListBaseにセット
            //DockStyle.Topにすると先にControls.Addしたものが下に行ってしまうので逆順にソートしておく
            addList.Reverse();
            foreach (Panel p in addList)
            {
                panelListBase.Controls.Add(p);
                p.Dock = DockStyle.Top;
            }
            panelListItem.AutoSize = true;

#if CHECK_OPERATION
            //PCB検査画面ページ指定起動関連
            await StartupPageDesignationFormInspection();
#else

            //***************************
            //工程一覧部の作成
            //***************************
            MakelistWork(true);
#endif
            //***************************
            //フォント設定
            //***************************
            SetFontName();

            //***************************
            //コントロールの表示文字列の設定
            //***************************
            SetCaptionControl();

            //***************************
            //コントロールの位置、サイズの指定
            //***************************
            SetLocationAndSizeControl();

            //***************************
            //検査日を取得
            //***************************
            historyInspect.InformationBasic.DataInspect = DateTime.Now.ToString("yyyy/MM/dd (ddd) HH:mm:ss");

            //***************************
            //画面ロード完了
            //***************************
            loadComplate = true;

            //***************************
            //最初の検査項目をカレントに設定
            //***************************
            currentDefinitionTable = listDefinition[0];

            //***************************
            //実施内容表示部を非表示にしてVisibleChangeイベントを発生させる
            //***************************
            panelInspection.Visible = false;
            await PanelInspectionVisibleChanged(panelInspection.Visible);
        }

        /// <summary>
        /// RSEL接続処理
        /// </summary>
        /// <param name="">-</param>
        /// <returns>true:接続OK、false:接続NG</returns>
        /// <remarks>RSELと接続する</remarks>
        /// <exception cref="System.Exception">RSELとの接続に失敗した時発生</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        protected async Task<bool> RselConnection()
        {
            bool resultConnect = false;
            //RSELと接続確立していない
            if (!OperateIFRegController.IsStateConnected)
            {
                try
                {
                    //RSELと接続
                    using (FormBusy form = new FormBusy(this, DisplayMethod.Control, CaptionRSEL + CaptionConnected + CaptionDo))
                    {
                        form.Show(this);
                        await Task.Run(async () =>
                        {
                            resultConnect = await ConnectOperateIFRegRsel(false, Settings.Default.PortMachineInspectRselOther);
                        });
                    }
                    if (!resultConnect)
                    {
                        AddLog(TypeLog.Bad, CaptionRSEL + MessageFailureConnection);
                        MessageBox.Show(CaptionRSEL + MessageHandlingFailureConnection,
                                        MessageBoxCaption_Warning,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Debugger.Log(0, ex.GetType().Name, ex.ToString());

                    AddLog(TypeLog.Bad, CaptionRSEL + MessageFailureConnection);
                    MessageBox.Show(CaptionRSEL + MessageHandlingFailureConnection,
                                    MessageBoxCaption_Warning,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// CUStation接続処理
        /// </summary>
        /// <param name="">-</param>
        /// <returns>true:接続OK、false:接続NG</returns>
        /// <remarks>CUStationと接続する</remarks>
        /// <exception cref="System.Exception">CUStationとの接続に失敗した時発生</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        protected async Task<bool> CUStationConnection()
        {
            bool resultConnect = false;
            //CUStationと接続確立していない
            if (OperateCUStationController.CommunicationStatus == CommunicationStatus.Disconnect)
            {
                try
                {
                    //CUStationと接続
                    using (FormBusy form = new FormBusy(this, DisplayMethod.Control, currentDefinitionTable.PageName + CaptionConnected + CaptionDo))
                    {
                        form.Show(this);
                        await Task.Run(async () =>
                        {
                            //CUStatitonのイベント追加
                            OperateCUStationController.TraceEvent += TracehEventHandler;
                            OperateCUStationController.PacketLogMessageIssuedEvent += PacketLogMessageIssuedEventHandler;
                            OperateCUStationController.ConnectEndEvent += ConnectEndEventHandler;
                            OperateCUStationController.ExceptionOccurredEvent += ExceptionOccurredEventHandler;
                            OperateCUStationController.ReadingRegistersProgressEvent += ReadingRegistersProgressEventHandler;
                            OperateCUStationController.TransmissionRegistersProgressEvent += TransmissionRegistersProgressEventHandler;
                            OperateCUStationController.ControlCommandReceivedEvent += ControlCommandReceivedEventHandler;
                            OperateCUStationController.ControlCommand2ReceivedEvent += ControlCommand2ReceivedEventHandler;
                            OperateCUStationController.DisconnectEndEvent += DisconnectEndEventHandler;

                            resultConnect = await ConnectCUStation(false, CuDeviceNo, CuConnectionSA);
                        });
                        if (!resultConnect)
                        {
                            AddLog(TypeLog.Bad, CaptionCUStation + MessageFailureConnection);
                            MessageBox.Show(CaptionCUStation + MessageHandlingFailureConnection,
                                            MessageBoxCaption_Warning,
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                            return false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debugger.Log(0, ex.GetType().Name, ex.ToString());

                    AddLog(TypeLog.Bad, CaptionCUStation + MessageFailureConnection);
                    MessageBox.Show(CaptionCUStation + MessageHandlingFailureConnection,
                                    MessageBoxCaption_Warning,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// CUStation切断処理
        /// </summary>
        /// <param name="">-</param>
        /// <returns>true:接続OK、false:接続NG</returns>
        /// <remarks>CUStationと接続する</remarks>
        /// <exception cref="System.Exception">CUStationとの接続に失敗した時発生</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        protected async Task<bool> CUStationDisConnection()
        {
            if (OperateCUStationController.CommunicationStatus != CommunicationStatus.Disconnect)
            {
                try
                {
                    OperateCUStationController.Disconnect();
                    //CUStatitonのイベント削除
                    OperateCUStationController.TraceEvent -= TracehEventHandler;
                    OperateCUStationController.PacketLogMessageIssuedEvent -= PacketLogMessageIssuedEventHandler;
                    OperateCUStationController.ConnectEndEvent -= ConnectEndEventHandler;
                    OperateCUStationController.ExceptionOccurredEvent -= ExceptionOccurredEventHandler;
                    OperateCUStationController.ReadingRegistersProgressEvent -= ReadingRegistersProgressEventHandler;
                    OperateCUStationController.TransmissionRegistersProgressEvent -= TransmissionRegistersProgressEventHandler;
                    OperateCUStationController.ControlCommandReceivedEvent -= ControlCommandReceivedEventHandler;
                    OperateCUStationController.ControlCommand2ReceivedEvent -= ControlCommand2ReceivedEventHandler;
                    OperateCUStationController.DisconnectEndEvent -= DisconnectEndEventHandler;
                }
                catch (Exception ex)
                {
                    Debugger.Log(0, ex.GetType().Name, ex.ToString());

                    AddLog(TypeLog.Bad, CaptionCUStation + MessageFailureDisConnection);
                    MessageBox.Show(CaptionCUStation + MessageHandlingFailureDisConnection,
                                    MessageBoxCaption_Warning,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// フォント設定
        /// </summary>
        protected void SetFontName()
        {
            CommonGui.SetFontName(this, DefalutFont);

            //検査指示の表示欄のみ文字サイズを大きくする
            labelDescription.Font = new Font(labelDescription.Font.FontFamily, SizeFontLabelDescription);
        }

        /// <summary>
        /// コントロールの表示文字列の設定
        /// </summary>
        protected void SetCaptionControl()
        {
        }

        /// <summary>
        /// コントロールの位置、サイズの指定
        /// </summary>
        protected void SetLocationAndSizeControl()
        {
            //全画面表示
            this.WindowState = FormWindowState.Maximized;

            //***************************
            //MANU/AUTO確認 指示ラベル
            //***************************
            //labelInstructionBlinking.Location = new Point((panelInspection.Width - labelInstructionBlinking.Width) / 2, labelDescription.Bottom + 40);
            labelInstructionBlinking.Location = new Point(labelDescription.Left + 40, labelDescription.Bottom + 40);
            labelInstructionBlinking.AutoSize = true;

            //***************************
            //次工程引き渡し 指示ラベル
            //***************************
            labelInviteReadingQrUnitAccessories.Location = new Point(labelDescription.Left + 40, labelDescription.Bottom + 40);
            labelInviteReadingQrUnitAccessories.Size = new Size(1000, 160);
            buttonConfirmedUnitAccessories.Size = new Size(140, 40);
            buttonConfirmedUnitAccessories.Location = new Point(labelInviteReadingQrUnitAccessories.Right + 10, labelInviteReadingQrUnitAccessories.Top + (labelInviteReadingQrUnitAccessories.Height - buttonConfirmedUnitAccessories.Height) / 2);

            labelInviteReadingQrSpecimen.Location = new Point(labelDescription.Left + 40, labelInviteReadingQrUnitAccessories.Bottom + 40);
            labelInviteReadingQrSpecimen.Size = labelInviteReadingQrUnitAccessories.Size;
            buttonConfirmedSpecimen.Size = new Size(140, 40);
            buttonConfirmedSpecimen.Location = new Point(labelInviteReadingQrSpecimen.Right + 10, labelInviteReadingQrSpecimen.Top + (labelInviteReadingQrSpecimen.Height - buttonConfirmedSpecimen.Height) / 2);

            //***************************
            //7セグ確認
            //***************************
            buttonConfirmedRdy.Size = new Size(140, 40);
            buttonConfirmedRdy.Location = new Point(labelDescription.Right - buttonConfirmedRdy.Width, labelDescription.Bottom + 10);

        }

        /// <summary>
        /// ボタンクリック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual async void buttonAction_Click(object sender, EventArgs e)
        {
            //検査項目に応じた処理を実施

            Console.WriteLine($"PageId: {currentDefinitionTable.PageId} ({(TypePage)currentDefinitionTable.PageId})");

            switch ((TypePage)currentDefinitionTable.PageId)
            {
                case TypePage.InputInspectionInformation:           //検査情報入力
                    await InputInspectionInformation();
                    break;

                case TypePage.SaveInspectionData:                   //検査データ保存       
                    //検査終了処理
                    await EndInspection();

                    CompletedInspection();
                    break;

                default:
                    //ステータス更新
                    await ProcessingOtherWhenButtonAction();
                    break;
            }
        }

        /// <summary>
        /// 完了処理その他
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected async Task ProcessingOtherWhenButtonAction()
        {
            try
            {
                await CompleteWork(StatusProcess.Complete);
                return;
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }
        }

        /// <summary>
        /// サブボタンクリック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual async void buttonSubAction_Click(object sender, EventArgs e)
        {
            //検査項目に応じた処理を実施
            switch ((TypePage)currentDefinitionTable.PageId)
            {
                default:
                    break;
            }
        }

        /// <summary>
        /// OKボタンクリック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void buttonOK_Click(object sender, EventArgs e)
        {
            try
            {
                await CompleteWork(StatusProcess.OK);

                return;
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }
        }

        /// <summary>
        /// NGボタンクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void buttonNG_Click(object sender, EventArgs e)
        {
            try
            {
                await CompleteWork(StatusProcess.NG);
                return;
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }
        }

        /// <summary>
        /// 中止ボタンクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            //中止フラグON
            StopInspectionAuto = true;
        }

        /// <summary>
        /// リトライボタンクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void buttonRetry_Click(object sender, EventArgs e)
        {
            if (currentDefinitionTable.TypeInspect == (int)TypeInspection.FunctionInspection)
            {//機能試験のとき

                try
                {
                    DisconnectOperateIFRegRsel(false);
                    if (!OperateIFRegController.IsStateConnected)
                    {//RSELとの接続が切れている場合再接続     
                        using (FormBusy form = new FormBusy(this, DisplayMethod.Control, CaptionRSEL + CaptionConnected + CaptionDo))
                        {
                            form.Show(this);
                            await Task.Run(async () =>
                            {
                                await ConnectOperateIFRegRsel(false, Settings.Default.PortMachineInspectRselOther);
                            });
                        }
                    }

                    //検査対象にアラームが出ている場合、アラームリセットをかける
                    if (OperateIFRegController.IsStateConnected)
                    {
                        using (FormBusy form = new FormBusy(this, DisplayMethod.Control, CaptionAlarmReset + CaptionDo))
                        {
                            form.Show(this);

                            StatusSystems status = OperateIFRegController.GetStatusSystem();
                            if (status.NoErrorUserSystemParamountcy != 0)
                            {//最重レベルシステムユーザーエラーNo. が0以外の場合アラームリセットを実施 
                                OperateIFRegController.AlarmReset();
                            }
                        }
                    }

                    //CUStationとの接続が切れている場合再接続 
                    DisconnectCUStation(false);
                    await CUStationConnection();

                    //初期化処理
                    await InspectionDeviceInitialization();
                }
                catch (Exception ex)
                {
                    Debugger.Log(0, ex.GetType().Name, ex.ToString());

                    MessageBox.Show(CaptionRetry + MessageHandlingException,
                                        MessageBoxCaption_Error,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                    return;
                }
            }

            //各自動検査項目のページ表示時(Visible=true時)処理と同等の処理を実施
            await PostProcessingOfPage();

            return;
        }

        /// <summary>
        /// フォームクロージングイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormInspection_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (!isAllowFormClose)
                {//フォームクローズをキャンセル
                    e.Cancel = true;
                    return;
                }

                //カレントをnullに設定
                currentDefinitionTable = null;

                //検査対象RSELと通信確立中であれば切断
                if (OperateIFRegController.IsStateConnected)
                {
                    OperateIFRegController.Disconnection();
                }

                //CUstaitionと通信確立中であれば切断
                if (OperateCUStationController.CommunicationStatus == CommunicationStatus.Connected)
                {
                    Task task = CUStationDisConnection(); 
                    task.Wait();
                }

                //分光器と通信確立中であれば切断
                if(SpectroScopeController != null)
                {
                    SpectroScopeController.DisConnect();
                }

                //完了log表示
                AddLog(TypeLog.Neither, CaptionThis + CaptionEnd);

                //ログファイル更新
                try
                {
                    UpdateLogFile();
                }
                catch (Exception ex)
                {
                    Debugger.Log(0, ex.GetType().Name, ex.ToString());

                    MessageBox.Show(MessageFailedToUpdateLogFile,
                                        MessageBoxCaption_Error,
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                }

                //画面クローズ成立
                CloseHold = true;

                return;

            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                MessageBox.Show(MessageFailedEnd,
                                    MessageBoxCaption_Error,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                //画面クローズ成立
                CloseHold = true;
            }
        }

        /// <summary>
        /// ログファイル更新(作成)
        /// </summary>
        protected virtual void UpdateLogFile()
        {
            try
            {
                //ファイル名の作成
                string nameFile;
                nameFile = NameLogInspection + ExtensionTxt;

                //ファイルパスの作成
                string pathFile = Path.Combine(Application.StartupPath, PathLog, nameFile);

                //ファイル更新(作成)
                using (StreamWriter stream = new StreamWriter(pathFile, true))
                {
                    string stringBeWritten = Environment.NewLine + richtextboxLog.Text;
                    stream.WriteLine(stringBeWritten);
                }
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                throw;
            }
        }

        /// <summary>
        /// 検査パネルのVisible状態によって実施する処理
        /// </summary>
        /// <param name="Visible"></param>
        protected virtual async Task PanelInspectionVisibleChanged(bool Visible)
        {
            if (!loadComplate || CloseHold)
            {
                return;
            }

            if (Visible == false)
            {//検査パネル非表示
                await PreProcessingOfPage();
            }
            else
            {//検査パネル表示後
                await PostProcessingOfPage();
            }
        }

        /// <summary>
        /// PCB検査画面定義テーブル作成
        /// </summary>
        protected virtual void CreateDefinitionTable()
        {
            listDefinition = new List<DefinitionTable>() { };

            //写真の表示trueのVer ※納入先交えた確認会で特に指摘も無かったので写真は非表示とする
            listDefinition.Add(new DefinitionTable((int)TypePage.InputInspectionInformation, (int)TypeInspection.PreInspectionWork, (int)TypeWorkSchedule.WorkManual, true, true, false, (int)TypeFooterButton.SingleButton, CaptionCompleted, false, string.Empty, false, false ));
            listDefinition.Add(new DefinitionTable((int)TypePage.InspectionDeviceInitialization, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.VariousVoltageCheck, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.VP3R3VoltageCheck, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.SwitchOperationCheck, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.NetworkSensorConnectionCheck, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.SensitivityAdjustmentCircuitOperationCheck, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.SensorCircuitOperationCheck, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.LEDDisplayCheck, (int)TypeInspection.FunctionInspection, (int)TypeWorkSchedule.CheckAllAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.WriteParameter, (int)TypeInspection.PostInspectionWork, (int)TypeWorkSchedule.WorkAutomated, false, false, false, (int)TypeFooterButton.RetryCancel, string.Empty, false, string.Empty, false, false));
            listDefinition.Add(new DefinitionTable((int)TypePage.SaveInspectionData, (int)TypeInspection.PostInspectionWork, (int)TypeWorkSchedule.WorkManual, false, false, true, (int)TypeFooterButton.SingleButton, CaptionSave, false, string.Empty, false, false));
        }

        /// <summary>
        /// 工程一覧部に工程を追加
        /// </summary>
        /// <param name="ListDefinition"></param>
        protected void AddWork<T>(List<DefinitionTable> ListDefinition)
        {
            //画面描画停止
            panelListBase.SuspendLayout();
            foreach (var definition in ListDefinition)
            {
                //----------------
                //工程一覧部の設定
                //----------------
                //検査項目パネルを一覧に追加する
                if (panelListItem.Controls.Cast<UserControlWorkSchedule>().Where(x => x.TypeInspect == definition.TypeInspect).ToList().Count == 0)
                {//試験区分が未追加であればヘッダーを作成する
                    UserControlWorkSchedule panelHeader = new UserControlWorkSchedule();
                    panelHeader.IsCompartment = true;
                    panelHeader.PageId = 0;
                    panelHeader.TypeInspect = definition.TypeInspect;
                    panelHeader.PageNameBackColor = Color.FromArgb(64, 64, 64);
                    panelHeader.PageName = GetEnumDescription((T)Enum.ToObject(typeof(T), definition.TypeInspect));
                    panelHeader.Dock = DockStyle.Bottom;
                    panelListItem.Controls.Add(panelHeader);
                }

                //検査項目パネル
                UserControlWorkSchedule panel = new UserControlWorkSchedule();
                panel.IsCompartment = false;
                panel.PageId = definition.PageId;
                panel.TypeInspect = definition.TypeInspect;
                panel.PageNameBackColor = GetBackColor(definition.TypeWork);
                panel.WorkStatus = StatusProcess.Incomplete;
                panel.PageName = definition.PageName;
                panel.Dock = DockStyle.Bottom;
                panelListItem.Controls.Add(panel);

            }
            panelListBase.ResumeLayout();
        }

        /// <summary>
        /// 作業完了処理
        /// </summary>
        /// <remarks>作業完了時の汎用的な処理</remarks>
        /// <param name="StatusProcessa">工程ステータス</param>
        /// <param name="LogDetail">logに表示するテキスト</param>
        protected async Task CompleteWork(StatusProcess StatusProcessa, string LogDetail = "")
        {
            //工程ステータスが完了、OK、NG以外は処理終了
            if (StatusProcessa != StatusProcess.Complete &&
                StatusProcessa != StatusProcess.OK &&
                StatusProcessa != StatusProcess.NG)
            {
                throw new Exception();
            }

            TypeLog typeLog = (StatusProcessa == StatusProcess.NG ? TypeLog.Bad : TypeLog.Good);
            AddLog(typeLog, $"{currentDefinitionTable.PageName}{GetEnumDescription(StatusProcessa)},{LogDetail}");

            //工程一覧部から現在の工程を取得
            var currentWork = panelListItem.Controls
                                .Cast<UserControlWorkSchedule>()
                                .FirstOrDefault(x => x.PageId == currentDefinitionTable.PageId);

            if (currentWork == null)
            {//取得できなければ処理終了
                throw new Exception();
            }

            // スキップ（対象外）項目なら処理を中断
            if (currentWork.WorkStatus == StatusProcess.Skipped)
            {
                return;
            }

            //工程一覧部のステータスを更新
            currentWork.WorkStatus = StatusProcessa;

            //工程ステータスがNG
            if (StatusProcessa == StatusProcess.NG)
            {
                MessageBox.Show(MessageCompleteNG,
                                MessageBoxCaption_Error,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }
            
            //次のページIDを取得
            // 基板グループ名を取得
            string selectedBoard = comboBoxInspectionSubstrate.Text;
            string boardGroup = GetBoardGroup(selectedBoard);

            // 検査対象のPageIdリストを取得
            List<int> validPageIds = BoardInspectionItems.ContainsKey(boardGroup)
                ? BoardInspectionItems[boardGroup]
                : new List<int>();

            // 現在の定義のインデックス取得
            int currentIndex = listDefinition.IndexOf(currentDefinitionTable);

            // 有効な次の定義を探す
            DefinitionTable nextDefinition = GetNextValidPage(validPageIds);

            if (nextDefinition == null)
            {//次のページIDがみつからない
                //終了メッセージ表示
                MessageBox.Show(MessageCompleteOK,
                                    MessageBoxCaption_Infomation,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);

                isAllowFormClose = true;
                this.Close();

                return;
            }

            // 次ページに遷移
            currentDefinitionTable = nextDefinition;

            //画面を非表示
            panelInspection.Visible = false;
            await PanelInspectionVisibleChanged(panelInspection.Visible);
        }

        private DefinitionTable GetNextValidPage(List<int> validPageIds)
        {
            int currentIndex = listDefinition.IndexOf(currentDefinitionTable);
            for (int i = currentIndex + 1; i < listDefinition.Count; i++)
            {
                if (validPageIds.Contains(listDefinition[i].PageId))
                {
                    return listDefinition[i];
                }
            }
            return null;
        }

        /// <summary>
        /// csv読み込み
        /// </summary>
        /// <param name="path"></param>
        private List<string> ReadCsv(string path)
        {
            List<string> list = new List<string>() { };

            using (StreamReader sr = new StreamReader(path, Encoding.GetEncoding("shift-jis")))
            {
                //末尾まで繰り返す
                while (!sr.EndOfStream)
                {
                    //1行づつ読み取る。
                    string line = sr.ReadLine();
                    list.Add(line);
                }
            }
            return list;
        }

        /// <summary>
        /// 検査項目取得
        /// </summary>
        /// <param name="path">DefinitionFormInspection.csvのパス</param>
        protected void GetInspectItem(string path)
        {

            //csvを読み込み
            List<string> csv = ReadCsv(path);

            bool firstRow = true;

            //画面左側の検査一覧を作成
            foreach (string line in csv)
            {
                string[] str = line.Split(',');

                if (firstRow)
                {//ヘッダー行は読み込まない
                    firstRow = false;
                    continue;
                }

                //項目が存在しなければ次の行へ
                if (str.Length <= 1)
                {
                    continue;
                }

                try
                {
                    //定義テーブルを更新
                    var update = listDefinition.Where(x => x.PageId == int.Parse(str[0])).ToList();

                    foreach (var definition in update)
                    {
                        definition.PageName = str[1];                               //ページ名
                        definition.Description = str[2];                            //説明文
                    }

                }
                catch (Exception ex)
                {
                    Debugger.Log(0, ex.GetType().Name, ex.ToString());

                    Console.WriteLine(ex.Message);
                }
            }
        }

        /// <summary>
        /// 背景色の取得
        /// </summary>
        /// <param name="type">工程区分</param>
        /// <returns></returns>
        private Color GetBackColor(int type)
        {
            switch ((TypeWorkSchedule)type)
            {
                case TypeWorkSchedule.CheckManual:
                    return colorCheckManual;

                case TypeWorkSchedule.CheckPartiallyAutomated:
                    return colorCheckPartiallyAutomated;

                case TypeWorkSchedule.CheckAllAutomated:
                    return colorCheckAllAutomated;

                case TypeWorkSchedule.WorkManual:
                    return colorWorkManual;

                case TypeWorkSchedule.WorkAutomated:
                    return colorWorkAutomated;

                default:
                    return colorCheckManual;
            }
        }

        /// <summary>
        /// ログ追加処理
        /// </summary>
        /// <param name="Type">ログ種別</param>
        /// <param name="Contents">内容</param>
        protected void AddLog(TypeLog Type, string Contents)
        {
            //現在アクティブなコントロールを取得
            Control focusedControl = this.ActiveControl;

            //現在時刻取得
            DateTime dt = DateTime.Now;

            //追加文字列の取得
            string addText = string.Empty;
            Color addTextColor;
            switch (Type)
            {
                case TypeLog.Good:
                    addText = GetEnumDescription(Type);
                    addTextColor = Color.White;
                    break;

                case TypeLog.Bad:
                    addText = GetEnumDescription(Type);
                    addTextColor = Color.Red;
                    break;

                case TypeLog.Neither:
                    addText = GetEnumDescription(Type);
                    addTextColor = Color.White;
                    break;

                default:
                    addText = string.Empty;
                    addTextColor = Color.White;
                    break;
            }

            string addId = string.Empty;
            if (currentDefinitionTable == null)
            {
                if (loadComplate == true)
                {
                    addId = CaptionSymbolClose;
                }
                else
                {
                    addId = CaptionSymbolLoad;
                }
            }
            else
            {
                addId = ((int)currentDefinitionTable.PageId).ToString();
            }

            StringBuilder sb = new StringBuilder();
            sb.Append(dt.ToString("yyyy/MM/dd HH:mm:ss"));      //日時
            sb.Append($",{addId}");                             //ページID
            sb.Append($",{addText}");                           //ログ種別毎の記号
            sb.Append($",{Contents}");                          //内容

            //追加するテキストの開始位置を取得
            int startIndex = richtextboxLog.TextLength;

            //カーソルを末尾に移動
            richtextboxLog.SelectionStart = startIndex;
            richtextboxLog.Focus();
            richtextboxLog.ScrollToCaret();

            //テキストを追加
            richtextboxLog.AppendText(sb.ToString() + "\r\n");

            //追加したテキストの色を変更
            richtextboxLog.Select(startIndex, sb.ToString().Length);
            richtextboxLog.SelectionColor = addTextColor;

            //フォーカスを外す
            panelFooter.Focus();

            //フォーカスを返す
            if (focusedControl != null)
            {
                focusedControl.Focus();
            }

        }

        /// <summary>
        /// ページ表示前
        /// </summary>
        private async Task PreProcessingOfPage()
        {

            //これから表示する画面のページIDを取得
            int pageId = (int)currentDefinitionTable.PageId;


            //ページIDをもとにPCB検査画面定義テーブルから画面情報を取得
            var definition = listDefinition.FirstOrDefault(x => x.PageId == pageId);

            //--------------------------
            //使用するコントロールの設定
            //--------------------------
            //タイトルを設定
            labelTitle.Text = definition.PageName;
            //タイトル背景色を設定
            labelTitle.BackColor = GetBackColor(definition.TypeWork);

            //説明を設定
            labelDescription.Text = definition.Description.Replace(@"\r\n", "\r\n");
            //サイズ調整
            int count = 0;
            var rows = labelDescription.Text.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            for (int i = 0; i < rows.Length; i++)
            {
                count += (rows[i].Length / 50);
                count++;
            }
            labelDescription.Height = (count + 1) * 30;

            //検査情報の設定
            groupboxInspectionInfo.Visible = definition.IsInfoInspection;
            if (definition.IsInfoInspection)
            {
                //位置調整
                groupboxInspectionInfo.Top = labelDescription.Bounds.Bottom + 40;
                groupboxInspectionInfo.Left = labelDescription.Left + (labelDescription.Width - groupboxInspectionInfo.Width) / 2;

                //QRコードから取得した出荷予定日を設定
                //datetimepickerDateShipping.Text = dataQR.QR4.ExpectShipmentDate;
                datetimepickerDateShipping.Value = DateTime.Today;

                //User.Configから検査者記憶用データを取得
                string dataForLearnInspector = Settings.Default.DataForLearnInspector;

                //検査者記憶用データをコンボボックスに設定
                var splitData = dataForLearnInspector.Split(',');
                comboboxInspectors.Items.AddRange(splitData);
                comboboxInspectors.SelectedIndex = 0;
            }

            if (definition.IsBoardInspection)
            {
                // 全選択肢 検査基板（固定）
                List<string> allBoards = new List<string>(Settings.Default.DataForAllSubstrate.Split(','));

                // 前回選択した基板を取得（1件だけでOK想定）
                string lastSelectedBoard = Settings.Default.DataForLearnSubstrate.Trim();
            
                // コンボボックス初期化
                comboBoxInspectionSubstrate.Items.Clear();

                // まず、前回選択が存在し、固定リストに含まれていたら一番上に追加
                if (!string.IsNullOrEmpty(lastSelectedBoard) && allBoards.Contains(lastSelectedBoard))
                {
                    comboBoxInspectionSubstrate.Items.Add(lastSelectedBoard);
                    // 残り（前回選択を除いたもの）を追加
                    foreach (var board in allBoards)
                    {
                        if (board != lastSelectedBoard)
                            comboBoxInspectionSubstrate.Items.Add(board);
                    }
                }
                else
                {
                    // 前回選択がなければ通常通り全候補
                    comboBoxInspectionSubstrate.Items.AddRange(allBoards.ToArray());
                }

                // 最初の選択位置をセット
                comboBoxInspectionSubstrate.SelectedIndex = comboBoxInspectionSubstrate.Items.IndexOf(lastSelectedBoard);

                // テキストボックス設定
                textBoxSubstrateLotNumber.Text = Settings.Default.SubstrateLotNumber;

            }

            //検査履歴コメントの設定
            groupboxComment.Visible = definition.IsVisibleHistoryComment;
            if (definition.IsVisibleHistoryComment)
            {
                //位置調整
                groupboxComment.Top = labelDescription.Bottom + 40;
                groupboxComment.Left = labelDescription.Left + (labelDescription.Width - groupboxComment.Width) / 2;
            }

            labelInviteReadingQrUnitAccessories.Visible = false;
            buttonConfirmedUnitAccessories.Visible = false;
            labelInviteReadingQrSpecimen.Visible = false;
            buttonConfirmedSpecimen.Visible = false;

            //フッターの設定
            switch (definition.TypeFooter)
            {
                case (int)TypeFooterButton.SingleButton:
                    panelSingleButton.Visible = true;
                    panelOKNG.Visible = false;
                    panelRetryCancel.Visible = false;
                    buttonAction.Text = definition.DisplayFooterName;

                    buttonSubAction.Text = definition.DisplayButtonSub;
                    buttonSubAction.Visible = definition.IsVisibleButtonSub;

                    break;

                case (int)TypeFooterButton.OKNG:
                    panelSingleButton.Visible = false;
                    panelOKNG.Visible = true;
                    panelRetryCancel.Visible = false;
                    break;

                case (int)TypeFooterButton.RetryCancel:
                    panelSingleButton.Visible = false;
                    panelOKNG.Visible = false;
                    panelRetryCancel.Visible = true;
                    break;

                default:
                    //何もしない
                    break;
            }

            //工程一覧部の次工程を取得
            var currentWork = panelListItem.Controls
                                .Cast<UserControlWorkSchedule>()
                                .FirstOrDefault(x => x.PageId == currentDefinitionTable.PageId);

            if (currentWork != null)
            {
                //工程一覧部の矢印を移動
                currentWork.Controls.Add(pictureboxCousol);
                pictureboxCousol.BringToFront();

                //工程一覧部のステータスを実施中に変更
                currentWork.WorkStatus = StatusProcess.Working;

                panelListBase.AutoScrollPosition = new Point(panelListBase.AutoScrollPosition.X, -panelListBase.AutoScrollPosition.Y + currentWork.Height);
            }

            //パネルを表示状態にする
            panelInspection.Visible = true;
            Update();
            await PanelInspectionVisibleChanged(panelInspection.Visible);
        }

        /// <summary>
        /// タブ移動の設定
        /// </summary>
        private void SettingTab(int pageId)
        {
            //一旦全てのコントロールのタブ移動を禁止する
            foreach (Control ctrl in this.Controls)
            {
                SetTabStopFalse(ctrl);
            }

            //タブ移動の設定
            int tabIndex = 0;
            Control[] control = new Control[0];
            switch ((TypePage)pageId)
            {
                case TypePage.InputInspectionInformation:
                    control = new Control[] { comboboxInspectors, buttonAction };
                    break;

                case TypePage.InspectionDeviceInitialization:
                    break;

                case TypePage.VariousVoltageCheck:
                    break;

                case TypePage.VP3R3VoltageCheck:
                    break;

                case TypePage.SwitchOperationCheck:
                    break;

                case TypePage.NetworkSensorConnectionCheck:
                    break;

                case TypePage.SensitivityAdjustmentCircuitOperationCheck:
                    break;

                case TypePage.SensorCircuitOperationCheck:
                    break;

                case TypePage.WriteParameter:
                    break;

                case TypePage.SaveInspectionData:
                    control = new Control[] { buttonAction };
                    break;

                default:
                    //何もしない
                    break;
            }

            for (int i = 0; i < control.Length; i++)
            {
                control[i].TabIndex = ++tabIndex;
                control[i].TabStop = true;
            }

            if (control.Length > 0)
            {
                control[0].Focus();
            }

            return;
        }

        void SetTabStopFalse(Control control)
        {
            control.TabStop = false;
            foreach (Control childControl in control.Controls)
            {
                SetTabStopFalse(childControl);
            }
        }

        /// <summary>
        /// ページ表示後関数
        /// </summary>
        protected virtual async Task PostProcessingOfPage()
        {
            //***************************
            //タブ移動の設定
            //***************************
            SettingTab(currentDefinitionTable.PageId);

            //***************************
            //自動検査項目準備処理
            //***************************
            bool isPreparationInspectionAuto = false;
            if (currentDefinitionTable.TypeWork == (int)TypeWorkSchedule.CheckPartiallyAutomated
                || currentDefinitionTable.TypeWork == (int)TypeWorkSchedule.CheckAllAutomated
                || currentDefinitionTable.TypeWork == (int)TypeWorkSchedule.WorkAutomated)
            {
                isPreparationInspectionAuto = true;
            }

            if (isPreparationInspectionAuto)
            {
                PreparationInspectionAuto(true);
            }

            //***************************
            //ページ毎の処理
            //***************************
            switch ((TypePage)currentDefinitionTable.PageId)
            {
                case TypePage.InspectionDeviceInitialization:        //検査機初期化処理                  
                    await InspectionDeviceInitialization();
                    break;

                case TypePage.VariousVoltageCheck: //各種電圧
                    await VariousVoltageCheck();
                    break;

                case TypePage.VP3R3VoltageCheck: //VP3R3電圧確認
                    await VP3R3VoltageCheck();
                    break;

                case TypePage.SwitchOperationCheck:  //スイッチ動作確認
                    await SwitchOperationCheck();
                    break;

                case TypePage.NetworkSensorConnectionCheck:  //ネットワーク・センサー接続確認
                    await NetworkSensorConnectionCheck();
                    break;

                case TypePage.SensitivityAdjustmentCircuitOperationCheck:  //感度調整回路動作確認
                    await SensitivityAdjustmentCircuitOperationCheck();
                    break;

                case TypePage.SensorCircuitOperationCheck:  //センサー回路動作
                    await SensorCircuitOperationCheck();
                    break;

                case TypePage.LEDDisplayCheck: //LED表示確認
                    await LEDDisplayCheck();
                    break;

                case TypePage.WriteParameter: //出荷パラメーター書込み処理
                    await WriteParameter();
                    break;

                default:
                    //何もしない
                    break;
            }

            //***************************
            //自動検査項目完了処理
            //***************************
            if (isPreparationInspectionAuto)
            {
                PreparationInspectionAuto(false);
            }

        }

        /// <summary>
        /// 自動検査項目準備処理
        /// </summary>
        /// <param name="IsProcessing">true：自動実行中、false：処理終了</param>
        /// <remarks>自動検査項目準備処理</remarks>
        protected void PreparationInspectionAuto(bool IsProcessing)
        {
            //リトライボタンの活性状態を切り替え
            buttonRetry.Enabled = !IsProcessing;

            //フォームクローズの可否を切り替え
            isAllowFormClose = !IsProcessing;

            //中止ボタンの活性状態を切り替え
            buttonCancel.Enabled = IsProcessing;

            //マウスカーソル変更(元に戻す)
            if (IsProcessing)
            {
                Cursor = Cursors.WaitCursor;
            }
            else
            {
                Cursor = Cursors.Default;
            }

            //コンテキストメニュー表示可否の切替
            IsEnableContextMenu = !IsProcessing;

            //中止フラグをoffにする
            StopInspectionAuto = false;
        }

        /// <summary>
        /// 工程一覧部の作成
        /// </summary>
        private void MakelistWork(bool IsBeforeReadQr)
        {

            // 基板グループ名を取得
            string selectedBoard = comboBoxInspectionSubstrate.Text;
            string boardGroup = GetBoardGroup(selectedBoard);

            // 検査対象のPageIdリストを取得
            List<int> validPageIds = BoardInspectionItems.ContainsKey(boardGroup)
                ? BoardInspectionItems[boardGroup]
                : new List<int>();

            //工程一覧部に「試験前作業」を追加
            AddWork<TypeInspection>(listDefinition.Where(x => x.TypeInspect == (int)TypeInspection.PreInspectionWork).ToList());
            //工程一覧部に「機能試験」を追加
            AddWork<TypeInspection>(listDefinition.Where(x => x.TypeInspect == (int)TypeInspection.FunctionInspection).ToList());
            //工程一覧部に「試験後作業」を追加
            AddWork<TypeInspection>(listDefinition.Where(x => x.TypeInspect == (int)TypeInspection.PostInspectionWork).ToList());

            //QRコード説明を表示しない
            panelQRReadInstruction.Visible = false;
        }

        /// <summary>
        /// 検査情報入力
        /// </summary>
        private async Task InputInspectionInformation()
        {
            try
            {
                //検査者名コンボボックスが空欄
                if (comboboxInspectors.Text.Trim() == string.Empty)
                {
                    AddLog(TypeLog.Bad, MessageNotSettingInspectorShort);
                    MessageBox.Show(MessageNotSettingInspectorLong,
                                    MessageBoxCaption_Warning,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                //検査履歴データHistoryInspectに現在設定されている検査者名をセット
                historyInspect.InformationBasic.Inspector = comboboxInspectors.Text.Trim();
                historyInspect.InformationBasic.DatatProduct = datetimepickerDateShipping.Value.ToString();

                //User.Configから検査者記憶用データを取得
                string dataForLearnInspector = Settings.Default.DataForLearnInspector;

                //検査者記憶用データをリストに変換
                List<string> splitData = dataForLearnInspector.Split(',').ToList();

                //User.Configの検査者一覧に現在設定されている検査者名が存在するか確認
                int splitIndex = splitData.IndexOf(historyInspect.InformationBasic.Inspector);
                if (splitIndex >= 0)
                {//存在すれば検査者一覧から現在の検査者の要素を削除
                    splitData.RemoveAt(splitIndex);
                }

                //検査者一覧の先頭要素として現在選択されている検査者名を追加
                splitData.Insert(0, historyInspect.InformationBasic.Inspector);

                if (splitData.Count > MaxInspectorName)
                {//検査者一覧の要素が10より多い
                 //検査者一覧内の末尾の要素を削除
                    splitData.RemoveAt(splitData.Count - 1);
                }

                //User.Configに書き込み
                Settings.Default.DataForLearnInspector = string.Join(",", splitData);
                Settings.Default.Save();

                //設定ファイルの保存パスの確認
                var appSettings = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.PerUserRoamingAndLocal);

                //検査基板選択コンボボックスが空欄
                if (comboBoxInspectionSubstrate.SelectedIndex == -1)
                {
                    AddLog(TypeLog.Bad, MessageNotBoardselectShort);
                    MessageBox.Show(MessageNotBoardselectLong,
                                    MessageBoxCaption_Warning,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                //検査履歴データHistoryInspectに現在設定されている基板名をセット
                historyInspect.InformationBasic.Substrate = comboBoxInspectionSubstrate.Text.Trim();

                //User.Configに書き込み
                Settings.Default.DataForLearnSubstrate = comboBoxInspectionSubstrate.Text.Trim();
                Settings.Default.DataForAllSubstrate = string.Join(",", comboBoxInspectionSubstrate.Items.Cast<string>());
                Settings.Default.Save();


                //基板ロット番号が空欄
                if (textBoxSubstrateLotNumber.Text.Length <= 7)
                {
                    AddLog(TypeLog.Bad, MessageNoSubstrateLotNumberShort);
                    MessageBox.Show(MessageNoSubstrateLotNumberLong,
                                    MessageBoxCaption_Warning,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                //検査履歴データHistoryInspectに現在設定されている基板名をセット
                historyInspect.TargetInspection.LotNo = textBoxSubstrateLotNumber.Text.Trim();

                //User.Configに書き込み
                Settings.Default.SubstrateLotNumber = textBoxSubstrateLotNumber.Text.Trim();
                Settings.Default.Save();


                //RSEL接続処理
                bool result = await RselConnection();
                if (!result)
                {
                    return;
                }

                //設定ファイル(Settings.settings)から保存済みの接続設定値を読み込む
                CuCommandSA = int.Parse(Settings.Default.ConnectionSa);
                CuMemoryAddress = (ushort)Convert.ToUInt16(Settings.Default.MemoryAddress, 16);
                CuMemoryByte = ushort.Parse(Settings.Default.MemoryByte);
                Spectrometer575 = ushort.Parse(Settings.Default.Spectroscope575);
                Spectrometer611 = ushort.Parse(Settings.Default.Spectroscope611);

                //CUStation接続処理
                result = await CUStationConnection();
                if (!result)
                {
                    return;
                }

                //ステータス更新
                await CompleteWork(StatusProcess.Complete, historyInspect.InformationBasic.Inspector);
                return;
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }
        }

        /// <summary>
        /// 検査終了処理
        /// </summary>
        /// <param name="">-</param>
        /// <returns>-</returns>
        /// <remarks>検査を終了する</remarks>
        /// <exception cref="System.Exception">検査機との通信に失敗した時</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        private async Task EndInspection()
        {
            try
            {
                //未接続なら終了
                if (!OperateIFRegController.IsStateConnected)
                {
                    return;
                }

                ClearAllOutputPorts();

                //リレー動作ウィエイト20ms以上
                await Task.Delay(20);

                //***************************
                //全有効軸分ステータス取得
                //***************************
                StatusAxis[] statusAxis = OperateIFRegController.GetStatusAxis(TargetNoGroupAxis);
                Array.Resize(ref statusAxis, NumberAxisEffect);

                //***************************
                //サーボOFF
                //***************************
                bool isServoON = false;
                foreach (StatusAxis thisStatusAxis in statusAxis)
                {
                    if (thisStatusAxis.StatusServo == ON)
                    {
                        isServoON = true;
                        break;
                    }
                }

                if (isServoON)
                {
                    OperateIFRegController.ChangeStateServo(false);
                }
            }
            catch (Exception ex)
            {
                Debugger.Log(0, ex.GetType().Name, ex.ToString());

                AddLog(TypeLog.Bad, MessageOccurrenceException);
                MessageBox.Show(currentDefinitionTable.PageName + MessageHandlingException,
                                MessageBoxCaption_Error,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }
        }


        /// <summary>
        /// コンボボックスの選択が変更された時の処理
        /// </summary>
        /// <param name="sender">イベント発生元オブジェクト</param>
        /// <param name="e">イベント情報</param>
        /// <returns>-</returns>
        /// <remarks>
        /// 選択された基板名を取得し、User.configに1件だけ保存した後、
        /// 基板グループ名を抽出して対応する検査項目IDリストを設定します。
        /// </remarks>
        /// <exception cref="">-</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        private void comboBoxInspectionSubstrate_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedBoard = comboBoxInspectionSubstrate.SelectedItem?.ToString();
        
            if (string.IsNullOrEmpty(selectedBoard))
                return;

            // 基板名を1件だけ User.config に保存
            Settings.Default.DataForLearnSubstrate = selectedBoard.Trim();
            Settings.Default.Save();

            // 基板グループ名に変換（例：IABS13801-000 → IABS13801）
            string boardGroup = GetBoardGroup(selectedBoard);
           
            if (BoardInspectionItems.ContainsKey(boardGroup))
            {
                CurrentTargetPageIds = BoardInspectionItems[boardGroup];
            }
            else
            {
                CurrentTargetPageIds = new List<int>(); // 対象なし
            }

            // 対象外のステータスに変更
            ApplySkippedStatus(CurrentTargetPageIds);
        }

        /// <summary>
        /// 基板名からグループ名を抽出
        /// </summary>
        /// <param name="fullBoardName">基板名</param>
        /// <returns>-</returns>
        /// <remarks>
        /// 基板名からグループ名を抽出します
        /// 例：「IABS13801-000」→「IABS13801」
        /// </remarks>
        /// <exception cref="">-</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        private string GetBoardGroup(string fullBoardName)
        {
            if (string.IsNullOrEmpty(fullBoardName)) return "";

            var parts = fullBoardName.Split('-');
            return parts[0];
        }

        /// <summary>
        /// 検査項目の状態設定
        /// </summary>
        /// <param name="validPageIds">ページIDのリスト</param>
        /// <returns>-</returns>
        /// <remarks>
        /// 対象の検査項目を、「未完了」、対象外の検索項目を「対象外(Skipped)」
        /// </remarks>
        /// <exception cref="">-</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        private void ApplySkippedStatus(List<int> validPageIds)
        {
            foreach (UserControlWorkSchedule panel in panelListItem.Controls.OfType<UserControlWorkSchedule>())
            {
                if (panel.PageId != 0) // ヘッダー除外
                {
                    panel.WorkStatus = validPageIds.Contains(panel.PageId)
                        ? StatusProcess.Incomplete
                        : StatusProcess.Skipped;

            
                }
            }
        }


        /// <summary>
        /// 基板ロット番号の16進数入力制御イベント
        /// </summary>
        /// <param name="sender">イベント発生元オブジェクト</param>
        /// <param name="e">イベント情報</param>
        /// <returns>-</returns>
        /// <remarks>基板ロット番号の16進数入力制御イベント</remarks>
        /// <exception cref="">-</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        private void textBoxSubstrateLotNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 入力された文字を取得
            char c = e.KeyChar;

            // バックスペースは許可
            if (char.IsControl(c))
            {
                return;
            }

            // 16進数文字（0-9, a-f, A-F）なら許可、それ以外は無効にする
            if (!Uri.IsHexDigit(c))
            {
                e.Handled = true;  // 入力をキャンセル
            }
        }


        /// <summary>
        /// 基板ロット番号の16進数入力制御イベント（貼り付けなど）
        /// </summary>
        /// <param name="sender">イベント発生元オブジェクト</param>
        /// <param name="e">イベント情報</param>
        /// <returns>-</returns>
        /// <remarks>基板ロット番号の16進数入力制御イベント（貼り付けなど）</remarks>
        /// <exception cref="">-</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        private void textBoxSubstrateLotNumber_TextChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.TextBox tb = (System.Windows.Forms.TextBox)sender;
            int selStart = tb.SelectionStart;

            // 有効な文字（0-9, A-F, a-f）のみ抽出
            string filtered = new string(tb.Text.Where(c => Uri.IsHexDigit(c)).ToArray());

            if (tb.Text != filtered)
            {
                tb.Text = filtered;
                tb.SelectionStart = selStart > tb.Text.Length ? tb.Text.Length : selStart;
            }
        }

        /// <summary>
        /// ロット番号を8文字に揃えるため、前に不足分の'0'を詰める処理
        /// </summary>
        /// <param name="sender">イベント発生元オブジェクト</param>
        /// <param name="e">イベント情報</param>
        /// <returns>-</returns>
        /// <remarks>足りない桁数分を'0'で前詰めし、合計8文字に整形</remarks>
        /// <exception cref="">-</exception>
        /// <Author>SCC</Author>
        /// <revisionHistory>
        /// 　<revision date="2025/6/30" version="Ver.1.0.0.0" author = "SCC" >
        /// 　  新規作成
        /// 　</revision>
        /// </revisionHistory>
        private void textBoxSubstrateLotNumber_Validated(object sender, EventArgs e)
        {
            var tb = (TextBox)sender;
            if (!string.IsNullOrEmpty(tb.Text))
            {
                tb.Text = tb.Text.PadLeft(8, '0');
            }
        }

        // --- ヘルパーメソッド ---

        private async Task<List<uint>> ReadRegistersAsync(ushort address, ushort count)
        {
            ReadingRegistersTcs = new TaskCompletionSource<ReadingRegistersProgressEventArgs>();
            OperateCUStationController.ReadHoldingRegisters(CuDeviceNo, CuCommandSA, address, count);
            var completed = await Task.WhenAny(ReadingRegistersTcs.Task, Task.Delay(3000));
            if (completed != ReadingRegistersTcs.Task)
            {
                AddLog(TypeLog.Bad, currentDefinitionTable.PageName + MessageFailureTimeout);
                MessageBox.Show(currentDefinitionTable.PageName + MessageFailureTimeout,
                                MessageBoxCaption_Warning, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            return ReadingRegistersTcs.Task.Result.RegistersReceived.Select(r => (uint)r.Value).ToList();
        }

        private async Task<bool> SendCommand2Async(uint command, uint op1, uint op2, string errorLabel, uint op3 = 0, uint op4 = 0)
        {
            Command2ReceiveTcs = new TaskCompletionSource<ControlCommand2ReceivedEventArgs>();
            OperateCUStationController.ControlCommand2(CuDeviceNo, CuCommandSA, command, op1, op2, op3, op4);
            var completed = await Task.WhenAny(Command2ReceiveTcs.Task, Task.Delay(3000));
            if (completed != Command2ReceiveTcs.Task)
            {
                var msg = errorLabel + "(" + MessageFailureTimeout + ")";
                AddLog(TypeLog.Bad, currentDefinitionTable.PageName + msg);
                MessageBox.Show(currentDefinitionTable.PageName + msg,
                                MessageBoxCaption_Warning, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (Command2ReceiveTcs.Task.Result.Status[0] != 0)
            {
                var msg = errorLabel + "(" + CaptionCommand2Result + ")";
                AddLog(TypeLog.Bad, currentDefinitionTable.PageName + msg);
                MessageBox.Show(currentDefinitionTable.PageName + msg,
                                MessageBoxCaption_Warning, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void ClearAllOutputPorts()
        {
            for (short port = OutPort0; port <= OutPort15; port++)
                OperateIFRegController.SetPortOne(port, OFF);
        }

        private async Task FailInspectionAsync(string message)
        {
            AddLog(TypeLog.Bad, currentDefinitionTable.PageName + message);
            await EndInspection();
            await CompleteWork(StatusProcess.NG);
        }
    }
}
