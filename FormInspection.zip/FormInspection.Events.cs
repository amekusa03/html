using IaiCorporation.AllPlatform.Misao.PhysicalTargetVirtualizationLayer2;
using System;

namespace IaiCorporation.PCBInspection_BarTypePhotoelectricSensor
{
    public partial class FormInspection
    {
        // CUStation 通信イベントハンドラー群
        // 接続／切断や受信の通知を受け取り、非同期待機中の TaskCompletionSource に結果を渡す。

        private void TracehEventHandler(object sender, EventArgs e) { }

        private void PacketLogMessageIssuedEventHandler(object sender, LogMessageIssuedEventArgs e) { }

        private void ConnectEndEventHandler(object sender, EventArgs e) { }

        private void ExceptionOccurredEventHandler(object sender, EventArgs e) { }

        private void TransmissionRegistersProgressEventHandler(object sender, TransmissionRegistersProgressEventArgs e)
        {
            TransmissionRegistersTcs?.TrySetResult(e);
        }

        private void ControlCommandReceivedEventHandler(object sender, ControlCommandReceivedEventArgs e) { }

        private void ControlCommand2ReceivedEventHandler(object sender, ControlCommand2ReceivedEventArgs e)
        {
            Command2ReceiveTcs?.TrySetResult(e);
        }

        private void DisconnectEndEventHandler(object sender, EventArgs e) { }

        private void ReadingRegistersProgressEventHandler(object sender, ReadingRegistersProgressEventArgs e)
        {
            ReadingRegistersTcs?.TrySetResult(e);
        }
    }
}
